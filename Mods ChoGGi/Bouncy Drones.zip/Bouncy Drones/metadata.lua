return PlaceObj("ModDef", {
	"title", "Bouncy Drones Rovers Colonists",
	"description", "Bouncy",
	"tags", "Misc",
	"id", "ChoGGi_BouncyDrones",
	"author", "ChoGGi",
	"version", 0.3,
  "image","BouncyDrones.jpg",
	"code", {
		"Script.lua",
	},
})
