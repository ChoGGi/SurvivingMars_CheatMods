return PlaceObj("ModDef", {
	"title", "Increased Render Distance",
	"description", "Further shadow, and model rendering\nThis is pretty useless without Increased Zoom Distance.",
	"tags", "Graphics",
	"id", "ChoGGi_IncreasedRenderDistance",
	"author", "ChoGGi",
	"version", 0.2,
  "image","IncreasedRenderDistance.png",
	"code", {
		"Script.lua",
	},
})
