return {
  PlaceObj('ModItemCode', {
    'FileName', "_CommonFunctions.lua",
  }),
  PlaceObj('ModItemCode', {
    'FileName', "OnMsgs.lua",
  }),
  PlaceObj('ModItemCode', {
    'FileName', "ReplacedFunctions.lua",
  }),
}
