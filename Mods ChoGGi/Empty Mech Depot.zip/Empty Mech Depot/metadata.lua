return PlaceObj("ModDef", {
  "saved", 1525867200,
  "version", 1,
  "title", "Empty Mech Depot",
  "description", "Empties out selected/moused over mech depot into a small depot in front of it (Ctrl-Shift-E).",
  "tags", "Building",
  "id", "ChoGGi_EmptyMechDepot",
  "author", "ChoGGi",
  "code", {
    "Functions.lua",
    "OnMsgs.lua",
  },
})
