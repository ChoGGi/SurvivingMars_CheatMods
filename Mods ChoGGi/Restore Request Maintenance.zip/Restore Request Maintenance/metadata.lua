return PlaceObj("ModDef", {
  "saved", 1527768000,
  "version", 1,
  "title", "Restore Request Maintenance v0.1",
  "description", "Restores \"Request Maintenance\" button.",
  "id", "ChoGGi_RestoreRequestMaintenance",
  "author", "ChoGGi",
  "code", {
    "Script.lua",
  },
})
