return PlaceObj("ModDef", {
  "saved", 1527854400,
  "version", 1,
  "title", "Permanent Priority v0.1",
  "description", "Priority from construction sites will carry over to the completed buildings.",
  "id", "ChoGGi_PermanentPriority",
  "author", "ChoGGi",
  "code", {
    "Script.lua",
  },
})
