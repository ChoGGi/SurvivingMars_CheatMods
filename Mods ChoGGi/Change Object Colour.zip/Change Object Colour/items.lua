return {
  PlaceObj('ModItemCode', {
    'FileName', "Functions.lua",
  }),
  PlaceObj('ModItemCode', {
    'FileName', "_CommonFunctions.lua",
  }),
  PlaceObj('ModItemCode', {
    'FileName', "Script.lua",
  }),
  PlaceObj('ModItemCode', {
    'FileName', "UIDesignerData.lua",
  }),
}
