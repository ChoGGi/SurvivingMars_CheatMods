return PlaceObj('ModDef', {
	'title', "Spire Buildings anywhere",
	'description', "Place Spire Buildings anywhere under the Dome ;) \r\nYou can place them outside of Domes too-But they not work there\r\nMade by BoehserOnkel",
	'tags', "",
	'id', "i5eMZdM",
	'author', "unknown",
	'version', 4,
	'saved', 1521572475,
})