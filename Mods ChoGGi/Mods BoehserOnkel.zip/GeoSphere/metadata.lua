return PlaceObj('ModDef', {
	'title', "GeoSphere",
	'description', "unlocks GeoSphere (two spires)",
	'tags', "",
	'id', "PRqlvsA",
	'author', "unknown",
	'version', 3,
	'saved', 1521504713,
})