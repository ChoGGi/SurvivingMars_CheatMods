--limit height of colonists section
XTemplates.sectionResidence[1]["MaxHeight"] = 128
XTemplates.sectionResidence[1]["Clip"] = true
