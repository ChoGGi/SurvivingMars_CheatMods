return PlaceObj('ModDef', {
	'title', "DroneFactory+",
	'description', "This Building no longer requires Workers\r\nby BoehserOnkel",
	'tags', "",
	'id', "GL4O5NA",
	'author', "BoehserOnkel",
	'version', 21,
	'saved', 1521642433,
})