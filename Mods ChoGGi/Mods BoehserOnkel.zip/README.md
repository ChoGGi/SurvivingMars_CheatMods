### No warranty implied or otherwise!

Mods by BoehserOnkel

##### Arcology+
```
Place for more People (120)
```
##### DroneFactory
```
This Building no longer requires Workers
```
##### GeoSphere
```
Add more than one GeoSphere
```
##### OvalDome
```
unlocks OvalDome from Marketing/Promotion
```
##### Spire Buildings anywhere
```
Place Spire Buildings anywhere under the Dome ;)
You can place them outside of Domes too-But they not work there
```
##### Storage+
```
Storages have space for 300  //UniversalStorage 100 each
```
