return PlaceObj("ModDef", {
	"title", "Add 5 Times The Resource To Deposits v0.1",
	"version", 1,
  "saved", 1533297600,
	"id", "ChoGGi_Add5TimesTheResourceToDeposits",
	"author", "ChoGGi",
	"code", {"Script.lua"},
  "image","Preview.png",
	"steam_id", "1427609324",
	"lua_revision", LuaRevision,
	"description", [[Adds a button to water/metal deposits to multiple the amount of ALL (water/metal) deposits by 5.

Requested by Peacemaker.]],
})