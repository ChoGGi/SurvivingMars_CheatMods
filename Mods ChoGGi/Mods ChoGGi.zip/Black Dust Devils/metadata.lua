return PlaceObj("ModDef", {
  "title", "Black Dust Devils v0.1",
  "version", 1,
  "saved", 1533297600,
	"image", "Preview.png",
  "tags", "Gameplay",
  "id", "ChoGGi_BlackDustDevils",
	"steam_id", "1411966010",
  "author", "ChoGGi",
  "code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[Makes all newly spawned dust devils black instead of brown.]],
})
