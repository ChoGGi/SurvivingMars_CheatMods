return PlaceObj("ModDef", {
	"title", "Auto Empty Full Waste Storage v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Misc",
	"id", "ChoGGi_AutoEmptyFullWasteStorage",
	"author", "ChoGGi",
  "image","Preview.png",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Automatically empties full waste storage depots.

Use Mod Config to toggle enabled, and hourly/daily empty]],
})
