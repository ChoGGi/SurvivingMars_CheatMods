return PlaceObj("ModDef", {
	"title", "Remove Moisture Vaporator Penalty v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_RemoveMoistureVaporatorPenalty",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Remove penalty when Moisture Vaporators are close to each other.]],
})