return PlaceObj("ModDef", {
  "title", "Construction: Show Hex Grid v0.1",
  "version", 1,
  "saved", 1533729600,

  "id", "ChoGGi_ConstructionShowHexGrid",
  "author", "ChoGGi",
	"code", {"Code/Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "steam_id", "1479851929",
  "description", [[Show Hex Grid during construction.]],
})
