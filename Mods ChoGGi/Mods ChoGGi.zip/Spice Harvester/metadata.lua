return PlaceObj("ModDef", {
  "title", "Spice Harvester v0.2",
  "version", 2,
  "saved", 1529323200,
	"image", "Preview.png",
  "tags", "Buildings",
  "id", "ChoGGi_SpiceHarvester",
  "author", "ChoGGi",
  "code", {"Script.lua"},
	"steam_id", "1416040484",
	"lua_revision", LuaRevision,
  "description", [[It doesn't do much; but move around and make thumping sounds at the moment.

Anyone up for making a better model?]],
})
