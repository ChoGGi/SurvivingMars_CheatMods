local SpiceHarvester = SpiceHarvester
local RGBA = RGBA

SpiceHarvester.UserSettings.Color = RGBA(83,37,3,255)

SpiceHarvester.UserSettings.Color1 = RGBA(69,32,3,255)

SpiceHarvester.UserSettings.Color2 = RGBA(85,40,13,255)

SpiceHarvester.UserSettings.Color3 = RGBA(53,25,2,255)

--I wouldn't set this too high...
SpiceHarvester.UserSettings.Max_Shuttles = 50

