return PlaceObj("ModDef", {
	"title", "Colonists: Avoid Workplace Sols v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_AvoidWorkplaceSols",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[After being fired, Colonists won't avoid that Workplace when searching for a Workplace.]],
})