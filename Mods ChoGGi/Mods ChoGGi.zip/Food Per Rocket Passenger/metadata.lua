return PlaceObj("ModDef", {
	"title", "Food Per Rocket Passenger v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_FoodPerRocketPassenger",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[The amount of Food supplied with each Colonist arrival (100).]],
})