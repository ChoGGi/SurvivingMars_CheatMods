return PlaceObj("ModDef", {
  "title", "Buildings Always Dusty v0.2",
  "version", 2,
  "saved", 1534334400,
  "id", "ChoGGi_BuildingsAlwaysDusty",
  "author", "ChoGGi",
	"steam_id", "1411885355",
  "code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[Buildings will never lose their dust. This is a visual mod, it doesn't affect maintenance.

Requested by: LegendGamer

Part of ECM.]],
})
