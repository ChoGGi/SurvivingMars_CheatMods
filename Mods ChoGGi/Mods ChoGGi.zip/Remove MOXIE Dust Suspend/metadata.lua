return PlaceObj("ModDef", {
  "title", "Remove MOXIE Dust Suspend v0.1",
  "version", 1,
  "saved", 1533297600,
  "id", "ChoGGi_RemoveMOXIEDustSuspend",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[Remove MOXIE Dust Suspend]],
})
