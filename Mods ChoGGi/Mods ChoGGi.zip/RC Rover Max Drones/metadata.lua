return PlaceObj("ModDef", {
	"title", "RC Rover Max Drones v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_RCRoverMaxDrones",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Maximum Drones an RC Rover can control (100).]],
})