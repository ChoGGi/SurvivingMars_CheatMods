return PlaceObj("ModDef", {
  "version", 2,
  "title", "Remove Stuff From Gardens v0.2",
  "saved", 1533384000,
  "id", "ChoGGi_RemoveStuffFromGardens",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
--~   "steam_id", "XXXXXXXXX",
	"lua_revision", LuaRevision,
  "description", [[Remove stuff from gardens]],
})
