return PlaceObj("ModDef", {
  "title", "Notification Pause v0.3",
  "version", 3,
  "saved", 1533297600,
  "id", "ChoGGi_NotificationPause",
  "author", "ChoGGi",
  "steam_id", "1411111982",
  "code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[Pauses the game on new notifications (also removes Drone Heavy Load notification).]],
})
