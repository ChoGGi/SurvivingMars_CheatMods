return PlaceObj("ModDef", {
	"title", "Bouncy Drones v0.3",
	"version", 3,
  "saved", 1533297600,
	"id", "ChoGGi_BouncyDrones",
	"author", "ChoGGi",
  "image","Preview.png",
  "steam_id", "1411104911",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Drones bounce when they move around (Colonists and Rovers default to no bounce).

You can change the bounce amount if you have Mod Config installed.

Part of ECM.]],
})
