return PlaceObj("ModDef", {
	"title", "Low Sanity Suicide Chance",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_LowSanitySuicideChance",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[0% Chance of suicide when Sanity reaches zero.]],
})