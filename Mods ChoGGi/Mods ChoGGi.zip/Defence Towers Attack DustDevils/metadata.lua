return PlaceObj("ModDef", {
  "title", "Defence Towers Attack DustDevils v0.1",
  "version", 1,
  "saved", 1533297600,
  "tags", "Cheats",
  "id", "ChoGGi_DefenceTowersAttackDustDevils",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[Defence towers will attack dustdevils.

Requested by: rdr99 and Emmote
https://steamcommunity.com/app/464920/discussions/0/2828702373008348129/]],
})
