return PlaceObj("ModDef", {
	"title", "Colonist: Applicant Generation Interval v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_ApplicantGenerationInterval",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[How long it takes to generate a new Applicant in the Applicant Pool. (1s)]],
})