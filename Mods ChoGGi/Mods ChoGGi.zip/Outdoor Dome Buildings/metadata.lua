return PlaceObj("ModDef", {
	"title", "Outdoor Dome Buildings v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_OutdoorDomeBuildings",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Add dome buildings outdoors (dome service buildings still need to be near domes).]],
})