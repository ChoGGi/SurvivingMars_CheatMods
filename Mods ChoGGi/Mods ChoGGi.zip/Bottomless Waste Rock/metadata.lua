return PlaceObj("ModDef", {
  "title", "Bottomless Waste Rock v0.1",
  "version", 1,
  "saved", 1533384000,
  "image", "Preview.png",
  "id", "ChoGGi_BottomlessWasteRock",
  "author", "ChoGGi",
  "steam_id", "1465688997",
  "code", {"Script.lua"},
	"lua_revision", LuaRevision,
  "description", [[Any rocks dumped at this depot will disappear (good for excess resources).

Be careful where you place it as drones will use it like a regular depot.

Requested by Black Jesus.]],
})
