return PlaceObj("ModDef", {
  "title", "Triboelectric Scrubbers Clean Dome Buildings v0.1",
  "version", 1,
  "saved", 1533124800,
	"image", "Preview.png",
  "id", "ChoGGi_TriboelectricScrubbersCleanDomeBuildings",
  "author", "ChoGGi",
  "steam_id", "1417507249",
  "code", {"Script.lua"},
	"lua_revision", LuaRevision,
  "description", [[They removed this in the Spirit Update.

Requested by Cinereously.]],
})
