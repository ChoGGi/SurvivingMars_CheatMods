return {
PlaceObj('ModItemCode', {
	'FileName', "Code/Script.lua",
}),
}
