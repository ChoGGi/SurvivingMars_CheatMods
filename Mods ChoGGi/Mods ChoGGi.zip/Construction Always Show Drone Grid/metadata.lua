return PlaceObj("ModDef", {
  "title", "Construction: Always Show Drone Grid v0.2",
  "version", 2,
  "saved", 1534334400,
  "id", "ChoGGi_ConstructionAlwaysShowDroneGrid",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
  "steam_id", "1424918098",
	"lua_revision", LuaRevision,
  "description", [[Shows grid radius around Drone Hubs and Rockets when you're in construction mode.

No luck with the RC Rovers grid.

Requested by mysticlife.]],
})
