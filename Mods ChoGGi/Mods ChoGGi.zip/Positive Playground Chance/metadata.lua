return PlaceObj("ModDef", {
	"title", "Positive Playground Chance v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_PositivePlaygroundChance",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[100% Chance to get a perk when grown if colonist has visited a playground as a child.]],
})