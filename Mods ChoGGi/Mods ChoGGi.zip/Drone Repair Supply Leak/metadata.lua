return PlaceObj("ModDef", {
	"title", "Drone Repair Supply Leak v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_DroneRepairSupplyLeak",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[The amount of time in seconds it takes a Drone to fix a supply leak (0 seconds).]],
})