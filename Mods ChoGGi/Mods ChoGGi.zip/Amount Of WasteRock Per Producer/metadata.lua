return PlaceObj("ModDef", {
  "title", "Amount Of WasteRock Per Producer v0.1",
  "version", 1,
  "saved", 1533297600,
  "id", "ChoGGi_AmountOfWasteRockPerProducer",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
  "steam_id", "1428163993",
	"lua_revision", LuaRevision,
  "description", [[Halves amount of waste rock each producer produces.

Requested by PichuTrainer.]],
})
