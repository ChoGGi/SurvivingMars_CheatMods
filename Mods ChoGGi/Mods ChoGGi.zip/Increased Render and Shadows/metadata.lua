return PlaceObj("ModDef", {
	"title", "Increased Render and Shadows v0.2",
	"version", 2,
  "saved", 1533297600,
	"tags", "Graphics",
	"id", "ChoGGi_IncreasedRenderDistance",
	"author", "ChoGGi",
  "image","Preview.png",
  "steam_id", "1411109283",
	"code", {"Script.lua"},
	"lua_revision", LuaRevision,
	"description", [[Further shadow, and model rendering
This is somewhat useless without increasing zoom in ECM.

You won't see the increased shadow/render difference, but you will have sharper shadows.

Part of ECM.]],
})
