return PlaceObj("ModDef", {
	"title", "Unlimited Wonders v0.1",
	"version", 1,
  "saved", 1533297600,
	"description", "Add as many Wonders as you want",
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_UnlimitedWonders",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
})