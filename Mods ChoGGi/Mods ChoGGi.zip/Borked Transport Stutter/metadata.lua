return PlaceObj("ModDef", {
	"title", "Borked Transport Stutter v0.2",
	"version", 2,
  "saved", 1533297600,
	"steam_id", "1440879916",
	"id", "ChoGGi_BrokedTransportStutter",
	"author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[RC Transports on a route have a certain tendency to get stuck and bog the game down (high speed feels like normal speed).

This'll check for and stop any borked ones (it'll show a popup msg when it stops one).]],
})