return PlaceObj("ModDef", {
	"title", "Default Outside Workplaces Radius v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_DefaultOutsideWorkplacesRadius",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Colonists search 256 hexes outside their Dome when looking for a Workplace.]],
})