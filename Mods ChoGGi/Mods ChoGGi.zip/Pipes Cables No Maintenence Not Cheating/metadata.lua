return PlaceObj("ModDef", {
	"title", "Pipes & Cables: No Maintenence, not cheating! v0.3",
	"version", 3,
  "saved", 1533297600,
	"id", "ChoGGi_NotCheatingPipesCablesNoMaintenence",
	"steam_id", "1410829032",
	"author", "ChoGGi",
	"TagOther", true,
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Definitely not a cheat...

https://steamcommunity.com/workshop/discussions/18446744073709551615/1694923613878153745/?appid=464920

Part of ECM.]],
})