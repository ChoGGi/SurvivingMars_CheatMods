--make it do nothing instead of breaking something
function SupplyGridFragment:RandomElementBreakageOnWorkshiftChange() end
