return PlaceObj("ModDef", {
	"title", "Auto Empty Waste Storage v0.3",
	"version", 3,
  "saved", 1533297600,
	"tags", "Misc",
	"id", "ChoGGi_AutoEmptyWasteStorage",
	"author", "ChoGGi",
  "image","Preview.png",
	"code", {"Script.lua"},
	"lua_revision", LuaRevision,
	"description", [[Automatically empties waste storage sites.

Use Mod Config to toggle enabled, and hourly/daily empty]],
})
