return PlaceObj("ModDef", {
  "title", "Selectable Cables v0.2",
  "version", 2,
  "saved", 1533297600,
	"image", "Preview.png",
  "id", "ChoGGi_SelectableCables",
  "author", "ChoGGi",
  "steam_id", "1411114741",
  "code", {"Script.lua"},
	"lua_revision", LuaRevision,
  "description", [[Name pretty much says it all.]],
})
