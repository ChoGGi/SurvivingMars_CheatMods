return PlaceObj("ModDef", {
	"title", "Unlock Research v0.1",
	"version", 1,
  "saved", 1533297600,
	"description", "See items.lua to pick tech to unlock (defaults to none)",
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_UnlockResearch",
	"image", "Preview.png",
})