### No warranty implied or otherwise!

See also: [nexus mods](https://www.nexusmods.com/survivingmars/users/659381?tab=user+files)
See also: [nexus misc mods](https://www.nexusmods.com/survivingmars/mods/77)

### These are all included in Expanded Cheat Menu, but if you want them...

##### OutdoorDomeBuildings
```
Add dome buildings outdoors (dome service buildings still need to be near domes).
doesn't mean they'll work properly, but they look nice.
Made Spires buildable in other spaces in domes (can't build them in spire place)< Thank you BoehserOnkel
```

##### DefensiveTurret
```
A laser-targeting defense structure. Protect nearby buildings from meteors. Can attack enemy vehicles at extreme range.
```

##### HiddenBuildings
```
Add hidden buildings to build menu...Warning: The ones in the "Hidden" category may break your game...
The Rocket Landing Site will break selection if you select it, so you'll need to manually uncomment it in items.lua (it's useless anyways).
Added a * to the names, to distinguish from the normal ones.
```

##### SanatoriumCureAll
```
Sanatoriums cure all negative traits, and Sanatorium+ treats 12 instead of 4 people at a time
Press F4 to toggle showing the full list of traits for it.
```

##### StopChildBirths
```
No more children born (maybe, untested)
```

##### NewColonistsYouth
```
Turns all born/sent from Earth Colonists into youths (no more dealing with children).
```

##### UnlimitedWonders
```
Add as many wonders as you want (the space elevator doesn't like it when there's more than one).
Added a * to the names, to distinguish from the normal ones.
```

##### AddFunding
```
Add 10M each time you load your game (open up items.lua to add another zero or two). You can load it once, save, then disable the mod.
```

##### UnlockResearch
```
Has a list of all research/breakthroughs, open items.lua and uncomment the ones you want to unlock (some names have spaces/misspelling, that's just how they are). Load the game and it'll unlock it, you can then disable it or just leave it enabled it doesn't matter.
You can change GrantTech to DiscoverTech, if you want to research it instead.
```

##### EnableCheats
```
Add a cheat section to the selection pane on the right (careful pressing malfunction, or emptying a mine), and a bunch of other cheats (commented out, see items.lua).
It'll allow you to fill up rockets with supplies, restock surface rock formations, quick build anything, etc.

Use the Cheat menu instead
```

##### AllPositiveTraits
```
Add all positive traits to ColonistArrived/ColonistBorn, and removes all negative.
If you already have people, and you want to apply this to them then open Script.lua and uncomment the function at the bottom (may be laggy on large colonies so I left it disabled).
```

##### LargerScannerQueue
```
Queue up all the squares instead of 5.
```

##### LargerResearchQueue
```
Queue up 25.
```

##### Remove Moisture Vaporator Penalty
```
Remove penalty when Moisture Vaporators are close
```

##### Others
```
ApplicantGenerationInterval (more colonists, not sure if working)
AvoidWorkplaceSols (fired people don't avoid same workplace for certain amount of time)
DroneMeteorMalfunctionChance (drone don't malfunc around meteors)
DroneRechargeTime (recharge takes 0 seconds)
DroneRepairSupplyLeak (repairs take 0 seconds)
FoodPerRocketPassenger (100 per person)
FundingPerSol (more money per sol / per rare metal)
LowSanityNegativeTraitChance (don't get neg trait when low sanity)
LowSanitySuicideChance (no suicide with low sanity)
MaxColonistsPerRocket (100 per rocket)
NoChanceOfSanityDamage (don't take sanity dmg from certain events)
NoCrimeBuildingDamage (no building dmg for crime)
NonSpecialistPerformancePenalty (removes penalty for non-specialist at job)
OutsideWorkplacesRadius (how far people look for a job outside their dome, be careful using this without suffocate mod)
PipesPillarSpacing (removes all those extra pillars when placing pipes)
PositivePlaygroundChance (chance for playground to give child good trait)
ProjectMorphiousPositiveTraitChance (gives a good trait while resting with Morphious enabled)
RCRoverDroneRechargeCost (makes the little drones recharge fast)
RCRoverFastResource (transfer/gather is faster, you may need to start new game)
RCRoverMaxDrones (100 drones per rover, you may need to start new game)
```