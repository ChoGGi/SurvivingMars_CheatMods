return PlaceObj("ModDef", {
	"title", "Stop Child Birth v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_StopChildBirths",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[No more children born]],
})