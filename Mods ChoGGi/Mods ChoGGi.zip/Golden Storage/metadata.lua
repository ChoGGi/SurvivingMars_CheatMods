return PlaceObj("ModDef", {
  "title", "Golden Storage v0.2",
  "version", 2,
  "saved", 1533384000,
	"image", "Preview.png",
  "id", "ChoGGi_GoldenStorage",
  "author", "ChoGGi",
  "steam_id", "1411108831",
	"code", {"Script.lua"},
	"lua_revision", LuaRevision,
  "description", [[Converts Metals to Precious Metals (10 to 1 ratio).]],
})
