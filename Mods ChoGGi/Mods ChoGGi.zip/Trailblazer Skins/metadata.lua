return PlaceObj("ModDef", {
	"title", "Add Trailblazer Skins v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_TrailblazerSkins",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Enable Trailblazer Skins.]],
})