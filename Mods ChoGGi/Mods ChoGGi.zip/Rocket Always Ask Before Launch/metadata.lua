return PlaceObj("ModDef", {
  "title", "Rocket: Always Ask Before Launch v0.1",
  "version", 1,
  "saved", 1533297600,
  "id", "ChoGGi_RocketAlwaysAskBeforeLaunch",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
  "steam_id", "1445727878",
	"lua_revision", LuaRevision,
  "description", [[If you've got a crappy wireless mouse that clicks too much, or you just want to be sure.

This displays the same confirmation you get when there's still cargo (your cargo isn't in any danger).

Requested by El Presidente.]],
})
