return PlaceObj("ModDef", {
  "title", "Permanent Priority v0.1",
  "version", 1,
  "saved", 1533297600,
	"image", "Preview.png",
  "id", "ChoGGi_PermanentPriority",
  "author", "ChoGGi",
  "steam_id", "1411112809",
	"code", {"Script.lua"},
	"lua_revision", LuaRevision,
  "description", [[Priority from construction sites will carry over to the completed buildings.]],
})
