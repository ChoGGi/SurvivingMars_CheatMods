return PlaceObj("ModDef", {
	"title", "Larger Scanner Queue v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_LargerScannerQueue",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Queue up to 100 squares instead of 5.]],
})