return PlaceObj("ModDef", {
  "title", "Restore Request Maintenance v0.1",
  "version", 1,
  "saved", 1533297600,
	"image", "Preview.png",
  "id", "ChoGGi_RestoreRequestMaintenance",
  "author", "ChoGGi",
  "steam_id", "1411114444",
	"code", {"Script.lua"},
	"lua_revision", LuaRevision,
  "description", [[Restores "Request Maintenance" button.]],
})
