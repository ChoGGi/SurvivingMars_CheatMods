return PlaceObj("ModDef", {
	"title", "Buildings: Defensive Turret",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_DefensiveTurret",
	"lua_revision", LuaRevision,
	"description", [[Add Defensive Turrets to Infrastructure menu.]],
})