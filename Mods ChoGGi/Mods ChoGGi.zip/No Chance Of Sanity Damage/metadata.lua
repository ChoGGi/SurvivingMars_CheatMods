return PlaceObj("ModDef", {
	"title", "No Chance Of Sanity Damage v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_NoChanceOfSanityDamage",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Stops sanity damage from certain events.]],
})