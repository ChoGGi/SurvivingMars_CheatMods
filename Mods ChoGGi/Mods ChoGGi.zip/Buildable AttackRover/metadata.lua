return PlaceObj("ModDef", {
  "title", "Buildable/Controllable AttackRover v0.1",
  "version", 1,
  "saved", 1533297600,
  "tags", "Buildings",
  "id", "ChoGGi_BuildableAttackRover",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[It doesn't do anything, that's your job.]],
})
