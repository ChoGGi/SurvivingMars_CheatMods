return PlaceObj("ModDef", {
	"title", "RC Transport Fast Resource v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_RCRoverFastResources",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[The time it takes for an RC Transport to Transfer/Gather resources (0s)]],
})