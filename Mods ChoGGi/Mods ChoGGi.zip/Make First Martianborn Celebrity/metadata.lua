return PlaceObj("ModDef", {
  "title", "Make First Martianborn Celebrity v0.1",
  "version", 1,
  "saved", 1533297600,
  "id", "ChoGGi_MakeFirstMartianbornCelebrity",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
  "steam_id", "1432940793",
	"lua_revision", LuaRevision,
  "description", [[The first Martianborn is always a celebrity (adds extra trait, doesn't replace any).
If you added the mod to a saved game, then it's whoever is born next.

(Kind of) requested by ehtalo.]],
})
