return PlaceObj("ModDef", {
  "title", "Sample Sidepanel Controls v0.1",
  "version", 1,
  "saved", 1533297600,
  "tags", "Modding",
  "id", "ChoGGi_SampleSidepanelControls",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[Adds some example controls to various side panel selections.]],
})
