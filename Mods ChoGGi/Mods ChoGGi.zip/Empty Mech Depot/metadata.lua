return PlaceObj("ModDef", {
  "title", "Empty Mech Depot v0.4",
  "version", 4,
  "saved", 1533297600,
	"image", "Preview.png",
  "tags", "Building",
  "id", "ChoGGi_EmptyMechDepot",
  "steam_id", "1411108310",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"lua_revision", LuaRevision,
  "description", [[Adds a button to mech depots to empty them out into a small depot in front of them.]],
})
