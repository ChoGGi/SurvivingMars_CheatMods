return PlaceObj("ModDef", {
	"title", "Hidden Buildings v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_HiddenBuildings",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Build the hidden buildings... WARNING: The ones in the Hidden category may break your game!]],
})