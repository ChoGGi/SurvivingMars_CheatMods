-- all this does is replace the func that unlocks them with nadda
function AchievementUnlock()
end
