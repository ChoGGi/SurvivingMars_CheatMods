return PlaceObj("ModDef", {
	"title", "Sanatorium Cure All v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_SanatoriumCureAll",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Sanatoriums cure all negative traits, and Sanatorium+ treats 12 instead of 4 people at a time]],
})