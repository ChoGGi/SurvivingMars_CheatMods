return PlaceObj("ModDef", {
	"title", "Add Funding v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_AddFunding",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Get 10M (Each time you load your saved game).]],
})