return PlaceObj("ModDef", {
  "saved", 1533124800,
  "version", 1,
  "title", "Lighter Dust Devils v0.1",
	"image", "Preview.png",
  "tags", "Gameplay",
  "id", "ChoGGi_LighterDustDevils",
  "author", "ChoGGi",
  "code", {"Script.lua"},
	"image", "Preview.png",
--~ 	"steam_id", "1411966010",
	"lua_revision", LuaRevision,
  "description", [[Makes all newly spawned dust devils lighter brown.]],
})
