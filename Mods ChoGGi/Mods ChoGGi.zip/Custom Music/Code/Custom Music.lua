function OnMsg.ClassesPostprocess()

  PlaceObj("RadioStationPreset",{
    display_name = [[Custom Music]],
    folder = "AppData/Music",
    group = "Default",
    id = "Custom_Music_FTW",
    silence = 1,
  })

end
