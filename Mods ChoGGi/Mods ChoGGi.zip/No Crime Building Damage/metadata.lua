return PlaceObj("ModDef", {
	"title", "No Crime Building Damage v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_NoCrimeBuildingDamage",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Sets the amount to 0 for CrimeEventSabotageBuildingsCount and CrimeEventDestroyedBuildingsCount (renegades).]],
})