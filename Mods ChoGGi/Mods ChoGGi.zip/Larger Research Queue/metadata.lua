return PlaceObj("ModDef", {
	"title", "Larger Research Queue v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_LargerResearchQueue",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Add up to 25 items]],
})