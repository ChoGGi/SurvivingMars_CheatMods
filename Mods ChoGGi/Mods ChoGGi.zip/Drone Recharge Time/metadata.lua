return PlaceObj("ModDef", {
	"title", "Drone Recharge Time v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_DroneRechargeTime",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[The time it takes for a Drone to be fully recharged. (0 seconds).]],
})