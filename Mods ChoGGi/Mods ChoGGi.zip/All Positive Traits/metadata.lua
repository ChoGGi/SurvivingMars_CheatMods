return PlaceObj("ModDef", {
	"title", "All Positive Traits v0.2",
	"version", 2,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_AllPositiveTraits",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Add all positive traits to ColonistArrived/ColonistBorn, and removes all negative, see the bottom of Script.lua to apply to colonists already born/arrived.]],
})