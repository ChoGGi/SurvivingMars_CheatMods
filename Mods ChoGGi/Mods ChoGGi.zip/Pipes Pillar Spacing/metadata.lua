return PlaceObj("ModDef", {
	"title", "Pipes Pillar Spacing v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_PipesPillarSpacing",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Less pillars per pipe run]],
})