return PlaceObj("ModDef", {
	"title", "Drone Meteor Malfunction Chance v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_DroneMeteorMalfunctionChance",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Drones will not malfunction when close to a meteor impact site.]],
})