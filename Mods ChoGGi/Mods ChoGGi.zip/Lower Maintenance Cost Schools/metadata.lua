return PlaceObj("ModDef", {
  "title", "Lower Maintenance Cost Schools v0.1",
  "version", 1,
  "saved", 1533297600,
  "id", "ChoGGi_LowerMaintenanceCostSchools",
  "author", "ChoGGi",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[Schools and Universities lower maintenance cost (half).]],
})
