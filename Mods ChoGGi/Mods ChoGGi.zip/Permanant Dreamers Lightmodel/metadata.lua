return PlaceObj("ModDef", {
	"title", "Permanant Dreamers Lightmodel v0.2",
	"version", 2,
	"saved", 1530964800,
	"id", "ChoGGi_PermanantDreamersLightmodel",
	"author", "ChoGGi",
  "image","Preview.png",
  "steam_id", "1433249476",
	"code", {"Script.lua"},
	"lua_revision", LuaRevision,
	"description", [[Always a green morning.

Part of ECM.

Requested by BLAde.]],
})
