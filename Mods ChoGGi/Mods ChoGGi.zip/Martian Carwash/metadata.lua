return PlaceObj("ModDef", {
  "title", "Martian Carwash v0.3",
  "version", 3,
  "saved", 1534334400,
	"image", "Preview.png",
  "id", "ChoGGi_MartianCarwash",
  "author", "ChoGGi",
  "steam_id", "1411110474",
	"code", {"Script.lua"},
	"lua_revision", LuaRevision,
  "description", [[Drive your ride through our full service car wash. You don't want to drive a dirty ride, and you shouldn't have to look at one.

This only affects visuals, not maintenance points.]],
})
