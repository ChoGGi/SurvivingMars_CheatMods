-- See LICENSE for terms

local LICENSE = [[
Any code that isn't mine is under the respective copyright of that author.

All of my code is licensed under the MIT License as follows:

MIT License

Copyright (c) [2018] [ChoGGi]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
]]

-- local any funcs used below (more than once)
local tonumber,tostring,pcall = tonumber,tostring,pcall
local AsyncRand,_InternalTranslate,T = AsyncRand,_InternalTranslate,T

-- easy place to store some info
local ChoGGi_MathFunctions = {
  _LICENSE = LICENSE,
  email = "SM_Mods@choggi.org",
  id = "ChoGGi_AddMathFunctions",
  ModPath = CurrentModPath,
}

-- just in case they remove oldTableConcat
local TableConcat
pcall(function()
  TableConcat = oldTableConcat
end)
TableConcat = TableConcat or table.concat
-- just in case etc
local floatfloor_tmp
pcall(function()
  floatfloor_tmp = floatfloor
end)

do -- translate
  --load up translation strings
  local function LoadLocale(file)
    if not pcall(function()
      LoadTranslationTableFile(file)
    end) then
      DebugPrintNL(string.format([[Problem loading locale: %s

Please send me latest log file: %s]],file,ChoGGi_MathFunctions.email))
    end
  end

  -- load locale translation
  local locale_file = TableConcat{ChoGGi_MathFunctions.ModPath,"Locales/",GetLanguage(),".csv"}
  if AsyncFileOpen(locale_file) then
    LoadLocale(locale_file)
  else
    LoadLocale(TableConcat{ChoGGi_MathFunctions.ModPath,"Locales/","English.csv"})
  end
  Msg("TranslationChanged")
end
-- locale id to string
local function trans(str)
  return _InternalTranslate(T{str})
end

local str = {
  not_implemented = trans(302535920010000--[[math.%s not implemented yet.--]]),
  error = trans(302535920010001--[[bad argument #%s to 'math.%s' (%s)--]]),
  zero = trans(302535920010002--[[zero--]]),
  less_than_or_equals_zero = trans(302535920010003--[[less than or equals zero--]]),
  less_than_zero = trans(302535920010004--[[less than zero--]]),
  arg2_arg1_less_than_zero = trans(302535920010005--[[arg#2 - arg#1 == less than zero--]]),
  test_start = trans(302535920010006--[[Testing math: Start--]]),
  test_end = trans(302535920010007--[[Testing math: End--]]),
  test_error = trans(302535920010008--[[Testing math: Error file: (%s) line number: (%s) val1: (%s) val2: (%s) func: (math.%s)--]]),
}

-- whenever i get .cos etc added (needed for unit testing)
--~ -- needed for tmp file when doing unit tests
--~ local mod_path = Mods.ChoGGi_AddMathFunctions.path
--~ local tmpfile = TableConcat{mod_path,"UnitTest.txt"}

local function CheckNum(x,name,arg)
  x = tonumber(x)
  if x then
    return x
  else
    print(str.error:format(arg or 1,name,"nan"))
    return 0/0
  end
end

-- global table holding all the functions
math = {}

--~   Returns the absolute value of x. (integer/float)
math.sm_abs = abs
function math.abs(x)
  x = CheckNum(x,"abs")

  if x < 0 then
    x = 0 - x
  end
  return x
end

--~   Returns the smallest integral value larger than or equal to x.
function math.ceil(x)
  x = CheckNum(x,"ceil")

  -- needed for neg numbers
  if x < 0 then
    x = x + 1 - (x % 1)
    return math.floor(x)
  end
  -- works fine on pos numbers
  return math.floor(x + 0.9)

end

--~   Converts the angle x from radians to degrees.
function math.deg(x)
  x = CheckNum(x,"deg")

  return x * 180.0 / math.pi
end

--~   Napier's constant/Euler's number (to 104 digits)
math.e = 2.71828182845904523536028747135266249775724709369995957496696762772407663035354759457138217852516642742746

--~   Returns the value e^x (where e is the base of natural logarithms).
function math.exp(x)
  x = CheckNum(x,"exp")

  return math.e^x
end

--~   Returns the largest integral value smaller than or equal to x.
math.floor = floatfloor_tmp or function(x)
  x = CheckNum(x,"floor")

  return x - (x % 1)
end

--~   Returns the remainder of the division of x by y that rounds the quotient towards zero. (integer/float)
function math.fmod(x, y)
  x = CheckNum(x,"fmod")
  y = CheckNum(y,"fmod",2)

  if y == 0 then
    print(str.error:format(2,"fmod",str.zero))
    return 0/0
  end

  if y < 0 then
    y = y * -1
  end

  local neg
  if x < 0 then
    neg = true
    x = x * -1
  end

  x = x % y
    if neg then
      return -x
    end
  return x

end

--~   The float value HUGE_VAL, a value larger than any other numeric value.
math.huge = 10e500 + 10e500

--~   Returns the logarithm of x in the given base. The default for base is e (so that the function returns the natural logarithm of x).
function math.log(x,base)
  x = CheckNum(x,"log")
  if x < 0 or tostring(x) == "0" then
    print(str.error:format(1,"log",str.less_than_or_equals_zero))
    return 0/0
  end

  if base then
    base = tonumber(base)
    if base then
      if base < 0 then
        print(str.error:format(2,"log",str.less_than_zero))
        return 0/0
      elseif base == 0 then
        return -0.0
      end
      if tostring(x) == "1" then
        return 0.0
      end

      return math.log(x) / math.log(base)
    else
      -- user put something for base that isn't a number
      print(str.error:format(2,"log","nan"))
      return 0/0
    end
  end

  -- no base means use
  base = math.e

--~   http://foldit.wikia.com/wiki/Lua_Script_Library#math.log_.28Taylor_Series_Approximation_.29
  local result = 0
  local residue = x / base
  while residue > 1 do
    residue = residue / base
    result = result + 1
  end
  local y = residue - 1
  -- just enough to get the same result as math.log()
  -- Taylor series
  residue = 1+y-y ^2/2+y ^3/3-y ^4/4+y ^5/5-y ^6/6+y ^7/7-y ^8/8+y
    ^9/9-y ^10/10+y ^11/11-y ^12/12+y ^13/13-y ^14/14+y ^15/15-y ^16/16+y
    ^17/17-y ^18/18+y ^19/19-y ^20/20+y ^21/21-y ^22/22+y ^23/23-y ^24/24+y
    ^25/25-y ^26/26+y ^27/27-y ^28/28+y ^29/29-y ^30/30+y ^31/31-y ^32/32+y
    ^33/33-y ^34/34+y ^35/35-y ^36/36+y ^37/37-y ^38/38+y ^39/39-y ^40/40+y
    ^41/41-y ^42/42+y ^43/43-y ^44/44+y ^45/45-y ^46/46+y ^47/47-y ^48/48+y
    ^49/49-y ^50/50+y ^51/51-y ^52/52+y ^53/53-y ^54/54+y ^55/55-y ^56/56+y
    ^57/57-y ^58/58+y ^59/59-y ^60/60+y ^61/61-y ^62/62+y ^63/63-y ^64/64
  result = result + residue
  return result
end

--~   Returns the argument with the maximum value, according to the Lua operator <. (integer/float)
math.max = Max

--~   An integer with the maximum value for an integer.
math.maxinteger = max_int

--~   Returns the argument with the minimum value, according to the Lua operator <. (integer/float)
math.min = Min

--~   An integer with the minimum value for an integer.
math.mininteger = min_int

--~   Returns the integral part of x and the fractional part of x. Its second result is always a float.
function math.modf(x)
  x = CheckNum(x,"modf")

  if math.type(x) == "integer" then
    return x,0.0
  end

  local neg
  if x < 0 then
    neg = true
    x = x * -1
  end

  local int = math.floor(x)

  if tostring(x) == tostring(int) then
    x = x % 1
  else
    x = x - int
  end

  if neg then
    return -int,-x
  end
  return int,x

end

--~   pi is pi is pi (to 104 digits)
math.pi = 3.14159265358979323846264338327950288419716939937510582097494459230781640628620899862803482534211706798214

--~   Converts the angle x from degrees to radians.
function math.rad(x)
  x = CheckNum(x,"rad")

  return x * math.pi / 180.0
end

--~   When called without arguments, returns a pseudo-random float with uniform distribution in the range [0,1).
--~   When called with two integers m and n, math.random returns a pseudo-random integer with uniform distribution in the range [m, n].
--~   (The value n-m cannot be negative and must fit in a Lua integer.) The call math.random(n) is equivalent to math.random(1,n).
function math.random(m,n)

  if m and n then
    m = CheckNum(m,"random")
    n = CheckNum(n,"random")
    if n-m < 0 then
      print(str.error:format("1 or #2","random",str.arg2_arg1_less_than_zero))
      return 0/0
    end

    return AsyncRand(n - m + 1) + m
  elseif m then
    m = CheckNum(m,"random")
    if m <= 0 then
      print(str.error:format(1,"random",str.less_than_or_equals_zero))
      return 0/0
    end

    return AsyncRand(m)
  else
    -- so it'll never return 1, close enough
    return tonumber(TableConcat{"0.",AsyncRand()})
  end

end

--~   Sets x as the "seed" for the pseudo-random generator: equal seeds produce equal sequences of numbers.
--~   The math.randomseed() function sets a seed for the pseudo-random generator: Equal seeds produce equal sequences of numbers.
math.randomseed = AsyncSetSeed

--~   Returns the square root of x.
function math.sqrt(x)
  x = CheckNum(x,"sqrt")
  if x < 0 then
    print(str.error:format(1,"sqrt",str.less_than_zero))
    return 0/0
  end

  return x^0.5
end

--~   If the value x is convertible to an integer, returns that integer. Otherwise, returns nil.
function math.tointeger(x)
  x = CheckNum(x,"tointeger")

  return math.floor(x)
end

--~   Returns "integer" if x is an integer, "float" if it is a float, or nil if x is not a number.
function math.type(x)
  x = CheckNum(x,"type")

  -- SM thinks 5.5 == 5...
  if tostring(math.floor(x)) == tostring(x) then
    return "integer"
  end
  return "float"
end

--~   Returns a boolean, true if and only if integer m is below integer n when they are compared as unsigned integers.
function math.ult(m, n)
  m = math.tointeger(m)
  n = math.tointeger(n)

--~     if m and n and m < n then
--~       return true
--~     end
--~     return false
  if m and n then
    if m < n then
      return true
    else
      return false
    end
  end
end



--~   Returns the cosine of x (assumed to be in radians).
math.sm_cos = cos
function math.cos(x)
  x = CheckNum(x,"cos")

  return math.sin(x + math.pi/2)
end

--~   Returns the sine of x (assumed to be in radians).
math.sm_sin = sin
function math.sin(x)
  x = CheckNum(x,"sin")

  print(str.not_implemented:format("sin"))
end

--~   Returns the tangent of x (assumed to be in radians).
function math.tan(x)
  x = CheckNum(x,"tan")

  print(str.not_implemented:format("tan"))
end

--~   Returns the arc cosine of x (in radians).
math.sm_acos = acos
function math.acos(x)
  x = CheckNum(x,"acos")

  print(str.not_implemented:format("acos"))
end

--~   Returns the arc sine of x (in radians).
math.sm_asin = asin
function math.asin(x)
  x = CheckNum(x,"asin")

  print(str.not_implemented:format("asin"))
end

--~   Returns the arc tangent of y/x (in radians), but uses the signs of both arguments to find the quadrant of the result. (It also handles correctly the case of x being zero.)
--~   The default value for x is 1, so that the call math.atan(y) returns the arc tangent of y.
math.sm_atan = atan
function math.atan(x)
  x = CheckNum(x,"atan")

  print(str.not_implemented:format("atan"))
end



--~ other functions



-- round down to nearest (default 1000)
function math.RoundDown(x, g)
  x = CheckNum(x,"RoundDown")
  g = CheckNum(g,"RoundDown",2)
  g = g or 1000
  return (x - x % g) / g * g
end

pcall(function()
  -- integer round up to nearest
  math.sm_RoundUp = round -- (number, granularity)

  math.sm_AngleNormalize = AngleNormalize -- (angle)
  math.sm_band = band -- (n1, n2)
  math.sm_bnot = bnot -- (n)
  math.sm_bor = bor -- (n1, n2)
  math.sm_bxor = bxor -- (n1, n2)
  math.sm_CatmullRomSpline = CatmullRomSpline -- (p1, p2, p3, p4, t, scale)
  math.sm_compare = compare -- (n1, n2)
  math.sm_DivCeil = DivCeil -- (v, d)
  math.sm_DivRound = DivRound -- (m, d)
  math.sm_FastSin = FastSin -- (a)
  math.sm_GetClock = GetClock
  math.sm_GetPreciseTicks = GetPreciseTicks
  math.sm_HermiteSpline = HermiteSpline -- (p1, m1, p2, m2, t, scale)
  math.sm_IsPowerOf2 = IsPowerOf2 -- (v)
  math.sm_maskset = maskset -- (flags, mask, value)
  math.sm_MulDivRound = MulDivRound -- (v, m, d)
  math.sm_MulDivTrunc = MulDivTrunc -- (v, m, d)
  math.sm_shift = shift -- (value, shift)
  math.sm_xxhash = xxhash -- (arg1, arg2, arg3)

  -- not really mathy
  math.sm_cs = cs
  math.sm_perlin = perlin
  math.sm_Encode16 = Encode16
  math.sm_Decode16 = Decode16
  math.sm_Encode64 = Encode64
  math.sm_Decode64 = Decode64
  math.sm_EaseCoeff = EaseCoeff
end)

-- deprecated

function math.pow(x,y)
  x = CheckNum(x,"pow")
  y = CheckNum(y,"pow",2)

  return x^y
end

function math.log10(x)
  x = CheckNum(x,"log10")

  return math.log(x,10)
end

function math.ldexp(x,exp)
  x = CheckNum(x,"ldexp")
  exp = CheckNum(exp,"ldexp",2)

  return x * 2.0^exp
end

--~ https://github.com/excessive/cpml/blob/master/modules/utils.lua
function math.frexp(x)
  x = CheckNum(x,"frexp")

  if x == 0 then
    return 0,0
  end
  local e = math.floor(math.log(math.abs(x)) / math.log(2) + 1)
  return x / 2 ^ e, e
end

math.atan2 = math.atan
math.mod = math.fmod

--~ https://github.com/NLua/LuaTests/blob/master/suite/math.lua (mostly)
function math.test()
  print(str.test_start)

  local getinfo = debug.getinfo
  local script_name = TableConcat{ChoGGi_MathFunctions.ModPath,"Script.lua"}

  local function Test(line,func,n1,n2)
    if n1 == false then
      print(str.test_error:format(script_name,line,n1,n2,func))
    elseif n1 and n2 and n1 ~= n2 then
      print(str.test_error:format(script_name,line,n1,n2,func))
    end
  end

  local function eq(a,b,limit)
    return math.abs(a-b) <= (limit or 10E-10)
  end

  Test(getinfo(1).currentline,"huge",math.huge > 10e30)
  Test(getinfo(1).currentline,"huge",-math.huge < -10e30)

  -- testing mod operator
  Test(getinfo(1).currentline,"pi",tostring(math.pi - math.pi % 1),"3.0")
  Test(getinfo(1).currentline,"pi",tostring(math.pi - math.pi % 0.001),"3.141")

--~     local function testbit(a, n)
--~       return a/2^n % 2 >= 1
--~     end

--~   Test(getinfo(1).currentline,"sin",eq(math.sin(-9.8)^2 + math.cos(-9.8)^2, 1))
--~   Test(getinfo(1).currentline,"tan",eq(math.tan(math.pi/4), 1))
--~   Test(getinfo(1).currentline,"sin",eq(math.sin(math.pi/2), 1) and eq(math.cos(math.pi/2), 0))
--~   Test(getinfo(1).currentline,"atan",eq(math.atan(1), math.pi/4) and eq(math.acos(0), math.pi/2) and
--~          eq(math.asin(1), math.pi/2))
  Test(getinfo(1).currentline,"deg",eq(math.deg(math.pi/2), 90) and eq(math.rad(90), math.pi/2))
  Test(getinfo(1).currentline,"abs",math.abs(-10),10)
--~   Test(getinfo(1).currentline,"atan2",eq(math.atan2(1,0), math.pi/2))
  Test(getinfo(1).currentline,"ceil",math.ceil(4.5),5)
  Test(getinfo(1).currentline,"floor",math.floor(4.5),4)
  Test(getinfo(1).currentline,"mod",math.mod(10,3),1)
  Test(getinfo(1).currentline,"sqrt",eq(math.sqrt(10)^2, 10))
  Test(getinfo(1).currentline,"log10",eq(math.log10(2), math.log(2)/math.log(10)))
  Test(getinfo(1).currentline,"exp",eq(math.exp(0), 1))

--~   Test(getinfo(1).currentline,"sin",eq(math.sin(10), math.sin(10%(2*math.pi))))
  local v,e = math.frexp(math.pi)
  Test(getinfo(1).currentline,"ldexp",eq(math.ldexp(v,e), math.pi))

--~   Test(getinfo(1).currentline,"tanh",eq(math.tanh(3.5), math.sinh(3.5)/math.cosh(3.5)))

--~   if rawget(_G, "_soft") then return end

--~   local AsyncStringToFile = AsyncStringToFile
--~   ThreadLockKey(tmpfile)
--~   AsyncStringToFile(tmpfile,"a = {","-1")
--~   i = 1
--~   repeat
--~     AsyncStringToFile(tmpfile,TableConcat{"{", math.sin(i), ", ", math.cos(i), ", ", i/3, "},\n"},"-1")
--~     i=i+1
--~   until i > 1000
--~   AsyncStringToFile(tmpfile,"}","-1")
--~   f:seek("set", 0)
--~   Test(getinfo(1).currentline,"sin",loadstring(select(2,AsyncFileToString(tmpfile))))()
--~   ThreadUnlockKey(tmpfile)

--~   Test(getinfo(1).currentline,"sin",eq(a[300][1], math.sin(300)))
--~   Test(getinfo(1).currentline,"sin",eq(a[600][1], math.sin(600)))
--~   Test(getinfo(1).currentline,"cos",eq(a[500][2], math.cos(500)))
--~   Test(getinfo(1).currentline,"cos",eq(a[800][2], math.cos(800)))
--~   Test(getinfo(1).currentline,"sin",eq(a[200][3], 200/3))
--~   Test(getinfo(1).currentline,"sin",eq(a[1000][3], 1000/3, 0.001))

  -- doesn't work in SM ("10e500 - 10e400" returns "-nan(ind)" instead of "nan")
--~   do   -- testing NaN
--~     local NaN = 10e500 - 10e400
--~     Test(getinfo(1).currentline,"nan",NaN ~= NaN)
--~     Test(getinfo(1).currentline,"nan",not (NaN < NaN))
--~     Test(getinfo(1).currentline,"nan",not (NaN <= NaN))
--~     Test(getinfo(1).currentline,"nan",not (NaN > NaN))
--~     Test(getinfo(1).currentline,"nan",not (NaN >= NaN))
--~     Test(getinfo(1).currentline,"nan",not (0 < NaN))
--~     Test(getinfo(1).currentline,"nan",not (NaN < 0))
--~     local a = {}
--~     Test(getinfo(1).currentline,"nan",not pcall(function () a[NaN] = 1 end))
--~     Test(getinfo(1).currentline,"nan",a[NaN],nil)
--~     a[1] = 1
--~     Test(getinfo(1).currentline,"nan",not pcall(function () a[NaN] = 1 end))
--~     Test(getinfo(1).currentline,"nan",a[NaN],nil)
--~   end

--~   require "checktable"
--~   stat(a)

--~   a = nil

  math.randomseed(0)

  for _ = 1, 10 do
    local t = math.random(5)
    Test(getinfo(1).currentline,"random",1 <= t and t <= 5)
  end

  local flag
  local i = 0
  local Max = -200
  local Min = 200
  repeat
    local t = math.random(-10,0)
    Max = math.max(Max, t)
    Min = math.min(Min, t)
    i=i+1
    flag = (Max == 0 and Min == -10)
  until flag or i>10000
  Test(getinfo(1).currentline,"random",-10 <= Min and Max<=0)
  Test(getinfo(1).currentline,"random",flag);

  -- tests I added

  Test(getinfo(1).currentline,"huge",math.huge + math.huge,math.huge)
  Test(getinfo(1).currentline,"log",tostring(math.log(1.1)),"0.095310179804325")
  Test(getinfo(1).currentline,"log",tostring(math.log(6.4643,25)),"0.57979705728765")
  Test(getinfo(1).currentline,"exp",tostring(math.exp(5.453454)),"233.56350262858")
  Test(getinfo(1).currentline,"exp",tostring(math.exp(-5.453454)),"0.0042814908525766")
  Test(getinfo(1).currentline,"fmod",tostring(math.fmod(56546.45645,1)),"0.45644999999786")
  Test(getinfo(1).currentline,"fmod",tostring(math.fmod(-56546.45645,1.5)),"-0.95644999999786")
  Test(getinfo(1).currentline,"fmod",tostring(math.fmod(-876.0007665,-1)),"-0.00076650000005429")
  Test(getinfo(1).currentline,"fmod",tostring(math.fmod(876.0007665,-1.6)),"0.80076650000001")
  Test(getinfo(1).currentline,"ceil",math.ceil(123.334546452),124)
  Test(getinfo(1).currentline,"ceil",math.ceil(-123.334546452),-123)
  Test(getinfo(1).currentline,"floor",math.floor(-123.525645644),-124)
  Test(getinfo(1).currentline,"floor",math.floor(123.525645644),123)

  local int,flt = math.modf(3453444.54354645)
  Test(getinfo(1).currentline,"modf",int,3453444)
  Test(getinfo(1).currentline,"modf",tostring(flt),"0.5435464498587")
  int,flt = math.modf(-3453444.54354645)
  Test(getinfo(1).currentline,"modf",int,-3453444)
  Test(getinfo(1).currentline,"modf",tostring(flt),"-0.5435464498587")

  -- check error msg
--~   Test(getinfo(1).currentline,"test",1,0)

  print(str.test_end)
end
