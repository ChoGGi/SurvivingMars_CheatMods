return PlaceObj("ModDef", {
	"title", "Max Colonists Per Rocket v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_MaxColonistsPerRocket",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Maximum number of Colonists that can arrive on Mars in a single Rocket (100).]],
})