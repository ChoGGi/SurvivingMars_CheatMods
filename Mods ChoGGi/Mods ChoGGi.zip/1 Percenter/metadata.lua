return PlaceObj("ModDef", {
  "title", "1 Percenter v0.1",
  "version", 1,
  "saved", 1533297600,
  "tags", "Cheats",
  "id", "ChoGGi_1Percenter",
  "author", "ChoGGi",
  "steam_id", "1411216506",
	"code", {"Script.lua"},
	"image", "Preview.png",
	"lua_revision", LuaRevision,
  "description", [[Receive a bonus of one percent of your funds each year.

Requested by: EasyMoney]],
})
