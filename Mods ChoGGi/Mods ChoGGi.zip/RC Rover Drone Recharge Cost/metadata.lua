return PlaceObj("ModDef", {
	"title", "RC Rover Drone Recharge Cost v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_RCRoverDroneRechargeCost",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[The amount of battery drained from RC Rover when recharging a Drone. (0)]],
})