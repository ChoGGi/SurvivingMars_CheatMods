return PlaceObj("ModDef", {
	"title", "Funding Per Sol v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_FundingPerSol",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[More Funding per sol]],
})