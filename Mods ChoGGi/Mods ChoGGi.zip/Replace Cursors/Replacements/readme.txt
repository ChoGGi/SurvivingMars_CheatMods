Place files (not folders) in Profile\Cursors. See Cursors\readme.txt for more help.
