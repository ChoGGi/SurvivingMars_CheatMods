To use custom cursors (won't be removed when this mod is updated):
Copy cursors to your profile folder\Cursors, like so:

Windows: %APPDATA%\Surviving Mars\Cursors
macOS/OSX: ~/Library/Application Support/Surviving Mars/Cursors
Linux: $XDG_DATA_HOME/Surviving Mars/Cursors
