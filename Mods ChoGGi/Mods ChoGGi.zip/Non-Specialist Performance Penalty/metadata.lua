return PlaceObj("ModDef", {
	"title", "Non-Specialist Performance Penalty v0.1",
	"version", 1,
  "saved", 1533297600,
	"tags", "Cheats",
	"author", "ChoGGi",
	"id", "ChoGGi_NonSpecialistPerformancePenalty",
	"image", "Preview.png",
	"lua_revision", LuaRevision,
	"description", [[Performance penalty for non-Specialists = 0]],
})