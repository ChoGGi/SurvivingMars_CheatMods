return PlaceObj('ModDef', {
	'title', "Archology+",
	'description', "Place for more People (120)\r\nby BoehserOnkel",
	'tags', "",
	'id', "Osa4crs",
	'author', "BoehserOnkel",
	'version', 8,
	'saved', 1521643432,
})