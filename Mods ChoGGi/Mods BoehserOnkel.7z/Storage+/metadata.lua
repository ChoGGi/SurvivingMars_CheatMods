return PlaceObj('ModDef', {
	'title', "Storage+",
	'description', "Storages have space for 300  //UniversalStorage 100 each\r\nmade by BoehserOnkel",
	'tags', "",
	'id', "RPjD65k",
	'author', "unknown",
	'version', 5,
	'saved', 1521635346,
})