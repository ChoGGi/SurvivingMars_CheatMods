function OnMsg.LoadGame()
Consts.BuildingMaintenancePointsModifier = -100
return true
end
