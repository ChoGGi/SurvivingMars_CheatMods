return PlaceObj('ModDef', {
	'title', "Hitchhikers Way",
	'description', "Just for Fun\r\nheavily cheatet\r\nincludes my Building Mods\r\ncredits to Darkedone02;ChoGGi for some parts",
	'tags', "",
	'id', "oG6ipfN",
	'author', "BoehserOnkel",
	'version', 76,
	'lua_revision', 228184,
	'code', {
		"Code/Script.lua",
		"Code/Script2.lua",
		"Code/Script3.lua",
		"Code/Script4.lua",
		"Code/Script5.lua",
	},
	'saved', 1522512402,
})