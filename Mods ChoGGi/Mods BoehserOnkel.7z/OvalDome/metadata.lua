return PlaceObj('ModDef', {
	'title', "OvalDome",
	'description', "unlocks OvalDome from Marketing/Promotion",
	'tags', "",
	'id', "cfm7fr4",
	'author', "unknown",
	'version', 2,
	'saved', 1521490142,
})