### No warranty implied or otherwise!

Automatically empties waste rock storage depots.
Use Mod Config to toggle enabled, and hourly/daily empty.