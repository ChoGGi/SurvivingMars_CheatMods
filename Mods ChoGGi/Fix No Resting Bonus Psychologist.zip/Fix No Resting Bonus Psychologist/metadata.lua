return PlaceObj("ModDef", {
	"title", "Fix No Resting Bonus Psychologist",
	"description", "The Psychologist profile is supposed to give a +5 sanity bonus to colonists during rest.",
	"tags", "Graphics",
	"id", "ChoGGi_FixNoRestingBonusPsychologist",
	"author", "ChoGGi",
	"version", 1,
	"code", {
		"Script.lua",
	},
})
