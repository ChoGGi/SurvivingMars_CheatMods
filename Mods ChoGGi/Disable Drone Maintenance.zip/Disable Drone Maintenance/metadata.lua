return PlaceObj("ModDef", {
  "saved", 1527854400,
  "version", 1,
  "title", "Disable Drone Maintenance v0.1",
  "description", "Adds a horizontal button to buildings to disable drones from performing maintenance.",
  "id", "ChoGGi_DisableDroneMaintenance",
  "author", "ChoGGi",
  "code", {
    "Script.lua",
  },
})
